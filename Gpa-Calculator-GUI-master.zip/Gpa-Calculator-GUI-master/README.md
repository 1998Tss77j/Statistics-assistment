# Gpa-Calculator-GUI [Tkinter]

What is GPA?
GPA means Grade Point Average. The GPA is a system of judging a student's performance and is followed throughout the United States.

If a student seeking admission to graduate studies has grades in a different system he/she should clearly mention that GPA system does not exist and provide details on the system.

In the event of a system different from the usual GPA system, some universities may ask for a detailed method of evaluation of the scores with their scales. In such case consult the Registrar or the controller of examination of the University for an official evaluation to be included along with the transcripts. It is recommended to send your rank certificate/official average score of class/toppers grades etc. to ease the difference between GPA and your system.

GPA is one of the most important factors to get admission in a good college. Higher GPA with above average GRE/SAT score can get you into top 50 College. Class rank can get you in a top 20 college. GPA is a clear indication of your academic record (it shows you have the ability to perform well in academics, no other score can give a better indication of your academics). As we all know General GRE/SAT doesn't test your academics (though people with high score have a good chance that they did well in academics too but it's not true especially for students outside the US). Class Rank/GPA is quite critical for international students.


US GPA System
Grade Points	Grade	Equivalent
4	A	High Achievement
3	B	Satisfactory
2	C	Minimum Passing
1	D	Failure

Please note: There are grades in between too.. (widely used by College grading system)

A 4.00
A- 3.67
B+ 3.33
B 3.00
B- 2.67
C+ 2.33
C 2.00
C- 1.67
D+ 1.33
D 1.00
D- 0.67
F 0.00
