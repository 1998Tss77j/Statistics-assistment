# Assignment-1-Q9_a-Basic-Statistics-Level-1-
Q9) Calculate Skewness, Kurtosis & draw inferences on the following data
      Cars speed and distance 
Use Q9_a.csv
